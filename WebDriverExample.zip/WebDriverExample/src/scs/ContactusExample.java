package scs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ContactusExample {

	public static void main(String[] args) throws InterruptedException {
		 System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 driver.get("https://shivaconceptsolution.com");
		 Thread.sleep(3000);
		 driver.findElement(By.className("close")).click();;
		 
		// System.out.print(ele.getAttribute("name"));
		 //ele.sendKeys("xyz");
		// WebElement ele1 = driver.findElement(By.name("email-712"));
		// ele1.sendKeys("xyz@gmail.com");	

	}

}
