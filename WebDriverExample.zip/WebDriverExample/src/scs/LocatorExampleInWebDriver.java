package scs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LocatorExampleInWebDriver {

	public static void main(String[] args) {
		  System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		  WebDriver driver = new ChromeDriver();
		  driver.get("http://shivaconceptsolution.com/test.html");
		  driver.manage().window().maximize();
		/*  driver.findElement(By.id("txt1")).sendKeys("Sumit"); 
		  driver.findElement(By.id("txt2")).sendKeys("123456789");
		  driver.findElement(By.id("txt3")).sendKeys("sumitrawat@12345");
		  driver.findElement(By.xpath("(//input[@id=\"txt3\"])[2]")).click(); */
		  driver.findElement(By.xpath("(//input[@id=\"txt3\"])[2]")).clear();
		  driver.findElement(By.xpath("(//input[@id=\"txt3\"])[2]")).sendKeys("03-06-2021");
		  driver.findElement(By.id("txt4")).sendKeys("9988776655"); 
		  Select s = new Select(driver.findElement(By.name("c[]")));
		  s.selectByIndex(1);
		  s.selectByIndex(3);
		  Select s1 = new Select(driver.findElement(By.id("c")));
		  s1.selectByIndex(3);
		  driver.findElement(By.name("chk1")).click();
		  driver.findElement(By.name("chk2")).click();
		  driver.findElement(By.name("chk2")).click();
		 // driver.findElement(By.linkText("Click")).click();
         // driver.findElement(By.partialLinkText(" shivaconcept")).click();
         // driver.navigate().back();
		//  driver.findElement(By.linkText("Click")).click();
		 // driver.navigate().back();
		//  driver.findElement(By.className("abc")).sendKeys("test classname");;
		//  driver.findElement(By.cssSelector("input#b")).sendKeys("test by id and tagname");
		//  driver.findElement(By.cssSelector("input[value=hello]")).clear(); 
         //  driver.findElement(By.cssSelector("input[value=hello]")).sendKeys("ssssssssssss"); 
		  //driver.findElement(By.cssSelector("input.abc")).sendKeys("tagname and  classname");;
	}

}
