package scs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigateCommandExample {

	public static void main(String[] args) throws InterruptedException {
		  System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
	      WebDriver driver = new ChromeDriver();
	      driver.get("https://shivaconceptsolution.blogspot.com/");
	      driver.navigate().to("https://shivaconceptsolution.blogspot.com/search/label/JAVASCRIPT%20LECTURE%20BY%20SHIVA%20SIR");
	      Thread.sleep(2000);
	      driver.navigate().back();

	}

}
