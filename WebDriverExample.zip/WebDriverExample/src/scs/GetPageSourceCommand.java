package scs;

import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetPageSourceCommand {

	public static void main(String[] args) throws IOException {
		System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://shivaconceptsolution.com");
		String s = driver.getPageSource();
		FileWriter fw = new FileWriter("d://scrap.txt");
		fw.write(s);
		fw.close();
		

	}

}
