package scs;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CountTextField {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 driver.get("https://shivaconceptsolution.com/contactus.php");
		 List<WebElement> we = driver.findElements(By.cssSelector("input[type='text']"));
		 System.out.println(we.size());
		 for(WebElement w:we)
		 {
			 System.out.print(w.getAttribute("placeholder"));
		 }
		 
		 

	}

}
