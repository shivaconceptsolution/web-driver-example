package scs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetCssValueExample {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 driver.get("https://shivaconceptsolution.com/test.html");
		 WebElement ele = 
		driver.findElement(By.cssSelector("input[value='click']"));
		/* String color = ele.getCssValue("color");
		 String width = ele.getCssValue("width");
		 System.out.println("color is "+color);
		 System.out.print("Width is "+width);
		 String s = ele.getAttribute("style");
		// System.out.println("data is "+s);
		 int begin = s.indexOf(":");
		 int last = s.indexOf(";");
		 String color = s.substring(begin+1,last);
		 System.out.print(color);*/
		 System.out.println(ele.getLocation());
		 System.out.println(ele.getLocation().x);
		 System.out.println(ele.getLocation().y);
		 driver.close();

	}

}
