package scs;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetCommandExample {

	public static void main(String[] args)  {
		System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://shivaconceptsolution.com/testmain.html");
		List<WebElement> we = driver.findElements(By.tagName("a"));
		ArrayList s = new ArrayList();
		for(WebElement w:we)
		{
			s.add(w.getAttribute("href"));
			
		}
		
		for(Object o:s)
		{
			driver.navigate().to(o.toString());
			driver.navigate().refresh();
			driver.navigate().back();
			//System.out.println(o);
		}
		driver.close();

	}

}
