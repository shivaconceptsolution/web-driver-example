package scs;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FindMaxImage {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 driver.get("https://shivaconceptsolution.com/test.html");
		 List<WebElement> we = driver.findElements(By.tagName("img"));
		 System.out.println(we.size());
		 int max=0;
		 for(WebElement w:we)
		 {
			 if(max<w.getSize().width)
			 {
				 max=w.getSize().width;
			 }
			 System.out.println(w.getSize());
		 }
		 
		 System.out.print("maximum width is "+max);

	}

}
