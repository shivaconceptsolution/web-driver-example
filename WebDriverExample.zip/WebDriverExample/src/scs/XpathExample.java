package scs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class XpathExample {

	public static void main(String[] args) {
		 System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
		 WebDriver driver = new ChromeDriver();
		 driver.get("https://shivaconceptsolution.com/test2.html");
		// driver.findElement(By.xpath("//html/body/input[2]")).sendKeys("XPATH EXAMPLE");;
		 driver.findElement(By.xpath("//*[@id='c']/input[1]")).sendKeys("Relative XPATH");
		 

	}

}
